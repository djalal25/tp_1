<?php 
//conexion base de donnée débuut 
$host = "localhost";
$db = "tp_1";
$user = "root";
$password = "";

$dns = "mysql:host=$host; dbname=$db; charset=UTF8";

try{
    $oPDO = new PDO($dns, $user, $password);

    if($oPDO){

        echo "Connected to $db database succesfully";//message pour confirmer la connexion a la base de donnée 
    } 
}  catch(PDOExeption $e){
    echo $e->getMessage();
}  
//conexion base de donée fin  
//pour acceder au dossier class et au fichier Alarm.php 
require_once "class/Alarme.php";
 echo "<br>";
 echo "<br>";
 //Affichage de toutes les alarmes
$alarme = new alarme;
var_dump($alarme->getAlarms());

echo "<br>";
echo "<br>";
//Affichage d une alarme 
$alarme2 = new alarme;
$id = 1;
var_dump($alarme2->getAlarme($id));


echo "<br>";
echo "<br>";
//methode pour rajouter une alarme
$alarme3 = new alarme;
$marque="apple";
$model="ET5";
$prix=50;

$alarme3->addAlarm($marque, $model, $prix) ;
var_dump($alarme3->getAlarme($alarme3->id));


echo "<br>";
echo "<br>";
$alarme4 = new alarme;
$id = 7;
var_dump($alarme4->deleteAlarme($id));


echo "<br>";
echo "<br>";
//methode pour mettre a jour une alarme 
$oalarme= new alarme;
$id = 5;
$alarme5= $oalarme->getAlarme($id);

$alarme5['prix'] = 1000;
$alarme5['model'] = "ETCCvc77";
$alarme5['marque'] = "HGGP";
$oalarme->updateAlarme($id,$alarme5);
echo "Mise a jour reusite";


echo "<br>";
echo "<br>";
//methode qui retourne une liste d alarme avec la meme marque
$alarme7= new alarme;
$marque = "HP";

var_dump($alarme7->getAlarmeWithMarque($marque));


?>