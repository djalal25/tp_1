<?php
class Electronique {
    public $id;
    public $marque;


    public function createElectronique($id,$marque){
        $this->id = $id;
        $this->prix = $marque;
        return;
    }    
    public function getElectronique(){
        return $this->marque;
    }    
    public function updateElectronique($data){
        $this->marque = $data['marque'];
        $this->id = $data['id'];

    }    
    public function deleteElectronique(){
        $this->id = 0;
        $this->prix ="";
        return;
    }
}
 ?>
 