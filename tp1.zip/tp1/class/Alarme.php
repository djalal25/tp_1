<?php

require_once "Electronique.php";

class Alarme extends Electronique{

    public $prix;
    public $model;

    // methode pour recuperer toutes les alarmes 
    
    public function getAlarms(){
        global $oPDO;
        //preparation de la requete sql
        $oPEDOStatement= $oPDO->query("SELECT id,model, marque,prix FROM alarme ");
        $alarmes= $oPEDOStatement->fetchAll(PDO::FETCH_ASSOC);
        return $alarmes;
    }


    // methode pour recuperer une alarm avec un id 
    public function getAlarme($id){
        global $oPDO;
        // preparer la requete 
        $oPEDOStatement = $oPDO->prepare("SELECT id,model, marque,prix FROM alarme WHERE id = :id");
    
        $oPEDOStatement->bindParam(':id',$id,PDO::PARAM_INT); 

        //execute de la requette préparée 
        $oPEDOStatement->execute();
        //récuperation des resultats 
        $alarme = $oPEDOStatement->fetch(PDO::FETCH_ASSOC);
        return $alarme;                  
    }
    //AJOUTER UN ITEME UNE ALARME 
    public function addAlarm($marque, $model, $prix) {
        global $oPDO;
        // Préparez la requête d'insertion
        $oPDOStatement = $oPDO->prepare('INSERT INTO alarme (marque, model, prix) VALUES (:marque, :model, :prix)');
        
        // Liez les valeurs aux paramètres de la requête
        $oPDOStatement->bindParam(':marque', $marque, PDO::PARAM_STR);
        $oPDOStatement->bindParam(':model', $model, PDO::PARAM_STR);
        $oPDOStatement->bindParam(':prix', $prix, PDO::PARAM_INT);
        
        // Exécutez la requête d'insertion
        $result = $oPDOStatement->execute();
        
        // Vérifiez si l'insertion a réussi et renvoyez le résultat
       return $result;
    }

    //methode pour mettre a jour une alarme
    public function updateAlarme($id,$data){
        global $oPDO;
        // Préparez la requête d'insertion
        $oPDOStatement = $oPDO->prepare('UPDATE alarme SET marque = :marque ,prix = :prix, model = :model WHERE id = :id');
        
        // Liez les valeurs aux paramètres de la requête
        $oPDOStatement->bindParam(':id', $id, PDO::PARAM_INT);
        $oPDOStatement->bindParam(':marque', $data['marque'], PDO::PARAM_STR);
        $oPDOStatement->bindParam(':model', $data['model'], PDO::PARAM_STR);
        $oPDOStatement->bindParam(':prix', $data['prix'], PDO::PARAM_INT);
        
        // Exécutez la requête d'insertion
        $result = $oPDOStatement->execute();
        
        // Vérifiez si l'insertion a réussi et renvoyez le résultat
       return $result;
    }

    //methode pour supprimer une alarme
    public function deleteAlarme($id){
        global $oPDO;
        // Préparez la requête d'insertion
        $oPDOStatement = $oPDO->prepare('DELETE FROM alarme WHERE id = :id ');
        
        // Liez les valeurs aux paramètres de la requête
        $oPDOStatement->bindParam(':id', $id, PDO::PARAM_INT);
        
        // Exécutez la requête d'insertion
        $result = $oPDOStatement->execute();
        
        // Vérifiez si l'insertion a réussi et renvoyez le résultat
       return $result;
    }

    //methode pour recuperer une ou plusieurs alarme/s avec sa/leurs marque/s 
    public function getAlarmeWithMarque($marque){
        global $oPDO;
        // preparer la requete 
        $oPEDOStatement = $oPDO->prepare("SELECT id,model, marque,prix FROM alarme WHERE marque = :marque");
    
        $oPEDOStatement->bindParam(':marque',$marque,PDO::PARAM_STR); 

        //execute de la requette préparée 
        $oPEDOStatement->execute();
        //récuperation des resultats 
        $alarme = $oPEDOStatement->fetchAll(PDO::FETCH_ASSOC);
        return $alarme;  
    }
        
}

?>    